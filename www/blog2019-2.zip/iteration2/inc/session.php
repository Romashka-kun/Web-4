<?php
  session_start();
  
  if ( $_SESSION['isAdmin'] )
	$isAdmin = true;
  else
	$isAdmin =  false;

?> 