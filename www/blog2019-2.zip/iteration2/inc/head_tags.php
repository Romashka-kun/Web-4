	<?php
	  //Общие для всех страниц сайта элементы <head>
	  //У нас это сейчас статичный HTML, но вполне вероятны и программные решения.
	?>
	<link href="style.css" type="text/css" rel="stylesheet" />
	<script src="https://code.jquery.com/jquery-1.10.2.js" integrity="sha256-it5nQKHTz+34HijZJQkpNBIHsjpV8b6QzMJs9tmOBSo=" crossorigin="anonymous"></script>
	<script src="script.js" type="text/javascript"></script>